EE4615 Design Submission - Group 22 (2-D Vernier TDC)
Daniel Tyukov (5714699), Joris Hoogeweegen (5619963)

Contents
--------
TDC22-Tyukov-Hoogeweegen-report.pdf   Final design report.

libraries/vernier2d/        Our design library (Cadence OpenAccess).
                            Cells: delay_tau1, delay_tau2 (FO=1 delay stages
                            with MOSCAP trim banks), nand, srlatch (arbiter),
                            Inv_10x/40x/80x and Inv_varx (buffers),
                            tdc_core (the full 2-D Vernier core),
                            plus cell testbenches (delay_tb, srlatch_tb,
                            nand_tb, nor_tb, vernier1d_row, vernier1d_tb).

libraries/Testbench/        The course Testbench library (TB_TDC, TDC, TDC_in,
                            TDC_out, POWER, td, ...). The design connects by
                            instantiating vernier2d/tdc_core in the td core
                            cell (pin-compatible: RESET, START, STOP,
                            VDD, GND, q1..q32).

ocean/course/               Unmodified course sweep scripts
                            (testbench_tdc_therm.ocn, testbench_tdc_binary.ocn).

ocean/characterization/     Our characterization scripts:
                            tdc_corners_all.ocn   five-corner staircase sweep
                                                  (env CORNER=tt|ss|ff|sf|fs)
                            tdc_tuned_all.ocn     same, with per-corner trim
                                                  codes via TRIM* env vars
                            tune_probe.ocn        64-configuration calibration
                                                  probe per corner
                            chosen_configs.txt    winning trim codes per corner
                            meta_sweep_*.ocn      arbiter metastability sweeps
                            v1d_*.ocn             1-D Vernier row comparison
                            srlatch_tb.ocn        arbiter cell verification
                            smoke_tt.ocn          quick 4-point TT check

Setup
-----
1. Register both libraries in cds.lib:
     DEFINE Testbench  <path>/libraries/Testbench
     DEFINE vernier2d  <path>/libraries/vernier2d
2. The TDC wrapper in Testbench instantiates the td core cell; td contains
   vernier2d/tdc_core. All simulations run on Testbench/TB_TDC with the
   TSMC 180 nm BCD models (sections tt_lib, ss_lib, ff_lib, sf_lib, fs_lib)
   at 27 C, VDD = 1.8 V.
3. Trim inputs trim<0:2> per line are static gate biases (0 / 1.8 V). The
   fixed configuration used for the uncalibrated corner results is the tuned
   TT setting; per-corner codes are in ocean/characterization/chosen_configs.txt
   and in Appendix A of the report.
